export class NodeModel {
  type: 'folder' | 'file' | 'unset' | null;
  name?: string;
  children?: NodeModel[];
  id: string;

  constructor() {
    let timeStamp = Date.now();
    this.id = String(timeStamp);
    this.type = 'unset';
    this.children = [];
  }
}
