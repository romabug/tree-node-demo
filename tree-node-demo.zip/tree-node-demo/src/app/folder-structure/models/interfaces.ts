export interface NodeType {
  filetype: 'folder' | 'file' | 'unset' | null;
}
