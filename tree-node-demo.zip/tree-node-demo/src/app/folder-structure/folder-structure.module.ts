import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';
import {FolderStructureComponent} from './folder-structure.component';
import {TreeNodeComponent} from './components/tree-node/tree-node.component';
import {ShowJsonComponent} from "./components/show-json/show-json.component";

@NgModule({
  declarations: [
    FolderStructureComponent,
    TreeNodeComponent,
    ShowJsonComponent
  ],
  imports: [
    CommonModule,
    BrowserAnimationsModule,
    FormsModule,
    HttpClientModule,
  ],
  exports: [FolderStructureComponent, ShowJsonComponent],
})
export class FolderStructureModule {
}
