import {NodeDataService} from './services/node-data.service';
import {Component, OnInit} from '@angular/core';
import {Observable, of} from "rxjs";
import {NodeModel} from "./models/model";
import {map} from "rxjs/operators";

@Component({
  selector: 'folder-structure',
  templateUrl: './folder-structure.component.html',
  styleUrls: ['./folder-structure.component.scss'],
})
export class FolderStructureComponent {
  treeData: Observable<NodeModel[]>;

  constructor(
    public nodeData: NodeDataService
  ) {
    this.treeData = this.nodeData.dataSubject
      .pipe(
        map(data => data)
      );
  }

  addFolder() {
    this.nodeData.addToRoot('folder');
  }

  removeChild(index: any) {
    this.nodeData.removeFromRoot(index);
  }

}
