import {NodeType} from "../models/interfaces";
import {NodeModel} from "../models/model";
import {BehaviorSubject} from "rxjs";

export class NodeDataService {
  treeData: NodeModel[] = [];
  dataSubject: BehaviorSubject<NodeModel[]> = new BehaviorSubject<NodeModel[]>([]);

  addToRoot(type: NodeType['filetype']): void {
    let node = new NodeModel();
    node.type = type;
    this.treeData.push(node);
    this.emitChanges();
  }

  getTreeData(): NodeModel[] {
    this.emitChanges();
    return this.treeData;
  }

  removeFromRoot(id: number): void {
    this.treeData.splice(id, 1);
    this.emitChanges();
  }

  emitChanges(){
    this.dataSubject.next(this.treeData);
  }
}
