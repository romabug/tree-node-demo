import {Component, Input} from '@angular/core';
import {NodeModel} from "../../models/model";

@Component({
  selector: 'show-json',
  template: `
    <pre>{{ treeJSON |json }}</pre>
  `
})
export class ShowJsonComponent  {
  @Input()
  treeJSON: NodeModel[]  = [];
}
