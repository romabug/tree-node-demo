import {Component, EventEmitter, Input, OnInit, Output} from '@angular/core';
import {NodeModel} from '../../models/model';
import {NodeType} from "../../models/interfaces";

@Component({
  selector: 'tree-node',
  templateUrl: './tree-node.component.html',
  styleUrls: ['./tree-node.component.scss'],
})
export class TreeNodeComponent {
  @Input()
  treeData: NodeModel[] | undefined = [];

  @Output()
  removeChildEvent = new EventEmitter<number>();
  @Output()
  addChildEvent = new EventEmitter<[NodeModel, NodeModel]>();

  name: string = '';

  setChildType(item: NodeModel, type: NodeType['filetype']) {
    item.type = type;
  }

  saveName(node: NodeModel) {
    node.name = this.name;
    this.name = '';
  }

  createChild(item: NodeModel) {
    let node = new NodeModel();
    this.addChild([item, node]);
  }

  addChild([item, node]: [NodeModel, NodeModel]) {
    item.children?.push(node);
  }

  removeNode(nodes: NodeModel[] | undefined, index: number) {
    nodes?.splice(index, 1);
    this.removeChildEvent.emit(index);
  }

  removeChild(item: NodeModel, index: number) {
    item.children?.splice(index, 1);
  }

  deleteChild(item: NodeModel, index: number) {
    this.removeChildEvent.emit(index);
  }
}
