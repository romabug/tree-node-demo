import {Component} from '@angular/core';
import {NodeDataService} from "./folder-structure/services/node-data.service";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  constructor(
    public nodeData: NodeDataService
  ) {
  }

}
