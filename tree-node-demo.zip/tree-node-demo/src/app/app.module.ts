import {NgModule} from '@angular/core';
import {BrowserModule} from '@angular/platform-browser';
import {AppComponent} from './app.component';
import {FolderStructureModule} from './folder-structure/folder-structure.module';
import {NodeDataService} from "./folder-structure/services/node-data.service";

@NgModule({
  declarations: [AppComponent],
  imports: [BrowserModule, FolderStructureModule],
  providers: [NodeDataService],
  bootstrap: [AppComponent],
})
export class AppModule {
}

